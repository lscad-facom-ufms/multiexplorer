./dwt2d 192.bmp -d 192x192 -f -5 -l 3
ls
./dwt2d rgb.bmp -d 1024x1024 -f -5 -l 3
