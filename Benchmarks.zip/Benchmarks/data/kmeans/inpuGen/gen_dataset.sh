#!/bin/bash

./datagen 100
./datagen 300
./datagen 1000
./datagen 3000
./datagen 10000
./datagen 30000
./datagen 100000
./datagen 300000
./datagen 1000000
./datagen 3000000
./datagen 10000000
./datagen 100 -f
./datagen 300 -f
./datagen 1000 -f
./datagen 3000 -f
./datagen 10000 -f
./datagen 30000 -f
./datagen 100000 -f
./datagen 300000 -f
./datagen 1000000 -f
./datagen 3000000 -f
./datagen 10000000 -f

