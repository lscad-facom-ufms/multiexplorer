./../Benchmarks/data/dwt2d/dwt2d ~/Benchmarks/data/dwt2d/192.bmp -d 192x192 -f -5 -l 3

./../Benchmarks/data/dwt2d/dwt2d ~/Benchmarks/data/dwt2d/rgb.bmp -d 1024x1024 -f -5 -l 3
